var express = require('express');
var bodyParser = require('body-parser');
const http=require('http')
var urlParser = bodyParser.urlencoded({extended : false})//处理 url 表单内容
var app = express();
const multer=require('multer')
let upload = multer({ dest: 'uploads/' })

let mongoose = require('mongoose')


    mongoose.connect("mongodb://127.0.0.1:27017/users", function (err,client) {
            if (!err) {
                console.log("连接数据库成功")
            }
            //let db=client.db('users');
            let usersSchema =new mongoose.Schema({
                name: {type: String, require: true},
                password: {type: String, require: true}
            })
            mongoose.model("users",usersSchema)

        })


    app.post('/upload1', urlParser, function (req, res) {

            let name=req.body.name
            let password = req.body.password
            let users = mongoose.model('users')
        // if(users.find({"name":name}).length=0) {
        //     users.create([{name: name, password: password}], (err) => {
        //         if (!err) {
        //             console.log("插入成功");
        //         } else {
        //
        //             throw err;
        //         }
        //     })
        // }
        // else {
        //     res.send("101")
        //     console.log("插入失败");
        // }
        users.find({"name":name},function (err,user) {
            if(user.length!=0){
                res.send("101")
            }
           else{

                users.create([{name: name, password: password}], (err) => {
                            if (!err) {
                                 console.log("插入成功");
                             } else {

                                 throw err;
                             }
                        })
                res.send("102")
            }
        })

})


        app.post('/upload2', urlParser, function (req, res, next) {
                        let name=req.body.name
                        let password = req.body.password
                            let users = mongoose.model('users')
                            users.find({"name":name},{"name":1,"password":1},function (err,user) {
                                  if(user.length!=0){

                                      if(user[0].password!=password){
                                          res.send("202")
                                      }
                                      else
                                          res.send(user[0].name)

                                  }
                                  else{
                                      res.send("201")
                                  }
                                // console.log(users)
                                  //    for(i=0;i<users.count;i++){
                                  //         if(users[i].name=name){
                                  //             if(users[i].password!=password){
                              //                 res.send("202")
                              //             }
                              //             else
                              //                 res.send(users[i].name)
                              //         }
                              //    }
                              //    if(users.count==0){
                              //        res.send("201")
                              //    }
                            })

                        })
    app.post('/upload3', upload.single('avatar1'), function (req, res, next) {
                let msg={
                body:req.body,
                file:req.file
            }
            res.json(msg)
        })

let server=http.createServer(app);
server.listen(8011,function () {
    console.log("start at port 8011")
})


